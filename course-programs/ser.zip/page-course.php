<?php get_header('course'); ?>

<?php get_footer(); ?>