<?php bloginfo('name'); ?> | 
<?php is_home() ? bloginfo('description') : wp_title(''); ?>